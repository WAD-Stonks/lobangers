#!/usr/bin/env python3
"""Build Lobang Pop Heavy from a user-provided lettering sample.

Letters visible in reference traced into outlines; uncovered Latin glyphs
come from an OFL-licensed Noto Sans Black with proportion adjustments.
All font software is distributed under SIL OFL 1.1. Python: fonttools,
Pillow, numpy, opencv, scipy and brotli.
"""
from __future__ import annotations
import os, math, copy
from pathlib import Path
import cv2
import numpy as np
from scipy.ndimage import gaussian_filter
from PIL import Image, ImageFont, ImageDraw
from fontTools.ttLib import TTFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.transformPen import TransformPen
from fontTools import subset
from fontTools.ttLib.tables._n_a_m_e import NameRecord

HERE=Path(__file__).resolve().parent
REF=HERE/'lettering-reference.png'
OUT=HERE.parent/'fonts'
OUT.mkdir(exist_ok=True)
FONT_IN=str(HERE/'NotoSans-Black.ttf')
# Character -> [left, top, right, bottom], with loose margins, pixels of image
RECTS={
 'B':(38,27,165,183), 'a':(168,57,273,181), 'n':(279,57,386,174),
 'g':(389,46,502,205), 'f':(538,26,635,179), 'r':(748,46,854,172),
 'y':(9,218,136,371), 'o':(132,218,244,336), 'u':(247,214,353,332),
 'b':(489,189,602,344), 'c':(706,211,794,334),'k':(793,183,902,342),
 '.':(904,295,946,341)
}
# Screenshot column and baseline, pixel per unit.
BASELINE={'B':178,'a':177,'n':172,'g':172,'f':174,'r':169,
          'y':331,'o':330,'u':327,'b':333,'c':331,'k':334,'.':335}
X_SCALE=5.14
Y_SCALE=5.03
MARGIN=18
RIGHT=25

img = cv2.imread(str(REF))
gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
font = TTFont(FONT_IN)
# Latin, Latin1, extended Latin and punctuation. Trim large font for web delivery.
opt=subset.Options()
opt.drop_tables += ['DSIG','fpgm','prep','cvt ']
opt.layout_features=['kern','liga']
opt.name_IDs=['*']; opt.name_languages=['*']
sub=subset.Subsetter(options=opt)
chars=set(range(0x20,0x250)) | {0x2013,0x2014,0x2018,0x2019,0x201C,0x201D,0x2022,0x2026,0x20AC,0x2122,0x00A0}
sub.populate(unicodes=chars)
sub.subset(font)
font['head'].created=font['head'].modified=3850000000
cmap=font.getBestCmap()
base_glyphs = font.getGlyphSet()
source_glyf=font['glyf']

# Screenshot letter bitmap, stored for derived glyphs.
def bitmap(char):
    x0,y0,x1,y1=RECTS[char]
    crop=gray[y0:y1,x0:x1]
    dark=(crop<128).astype(np.uint8)
    # Avoid accidental characters and coloured ornament via main connected component.
    num,labels,st,cntr=cv2.connectedComponentsWithStats(dark,8)
    biggest=1+np.argmax(st[1:,cv2.CC_STAT_AREA])
    yy,xx=np.where(labels==biggest)
    mask=np.zeros_like(crop,dtype=np.uint8)
    mask[yy,xx]=255
    # Keep bboxes tight, include 3 px padding.
    a,b=xx.min(),xx.max()+1; c,d=yy.min(),yy.max()+1
    tight=np.pad(mask[c:d,a:b],4,constant_values=0)
    return tight,(x0+a-4,y0+c-4)

bitmap_cache={c:bitmap(c) for c in RECTS}

def glyph_from_binary(img_mask, xorig, yorig, baseline):
    """Trace smoothed artwork to compact native quadratic TrueType curves."""
    p=np.pad(img_mask,3)
    sm=gaussian_filter(p.astype(float)/255.0,sigma=0.82)
    mask=(sm>0.48).astype(np.uint8)*255
    contours,hier=cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    pen=TTGlyphPen(None)
    xmin,xmax=100000,-100000
    def xy(pt):
        nonlocal xmin,xmax
        xx=MARGIN+(xorig + pt[0]-3)*X_SCALE
        yy=(baseline-(yorig+pt[1]-3))*Y_SCALE
        xmin=min(xmin,xx);xmax=max(xmax,xx)
        return (int(round(xx)),int(round(yy)))
    for cont in contours:
        if cv2.contourArea(cont)<7:
            continue
        approx=cv2.approxPolyDP(cont,1.18,True).reshape(-1,2)
        if len(approx)<3: continue
        pts=[xy(pt) for pt in approx]
        n=len(pts)
        mid=lambda a,b:(int(round((a[0]+b[0])/2)),int(round((a[1]+b[1])/2)))
        pen.moveTo(mid(pts[-1],pts[0]))
        for i in range(n):
            # Smoothing via tangent quadratic sections keeps bubbly organic edges.
            pen.qCurveTo(pts[i],mid(pts[i],pts[(i+1)%n]))
        pen.closePath()
    glyph=pen.glyph()
    return glyph,int(max(160,math.ceil(xmax+RIGHT)))

# Input letters -> map coords relative to glyph crop's left, preserving photo's
# vertical levels. Remove the screenshot's initial x-position from baseline mapping.
for char,(mask,(origin_x,origin_y)) in bitmap_cache.items():
    gname=cmap.get(ord(char))
    if not gname: continue
    gl,w=glyph_from_binary(mask,-4,origin_y,BASELINE[char])
    source_glyf[gname]=gl
    font['hmtx'][gname]=(w,MARGIN)

# Helpers for drawn secondary lowercase glyphs. Morph screenshot letters instead
# of using dissimilar fallback shapes where simple composites work.
def mask_glyph(mask,base_y=0,xscale=X_SCALE,yscale=Y_SCALE,xpad=18):
    # Separate coordinates: pixel x=0 at glyph origin; y rows from image top.
    h,w=mask.shape
    blur=gaussian_filter(mask.astype(float)/255,sigma=0.90)
    contours,_=cv2.findContours((blur>0.47).astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    pen=TTGlyphPen(None)
    for ct in contours:
        if cv2.contourArea(ct)<12: continue
        ap=cv2.approxPolyDP(ct,1.08,True).reshape(-1,2)
        if len(ap)<3:continue
        pp=[(int(round(xpad+x*xscale)),int(round(base_y+(h-1-y)*yscale))) for x,y in ap]
        mid=lambda a,b:(int(round((a[0]+b[0])/2)),int(round((a[1]+b[1])/2)))
        pen.moveTo(mid(pp[-1],pp[0]))
        for i in range(len(pp)):
            pen.qCurveTo(pp[i],mid(pp[i],pp[(i+1)%len(pp)]))
        pen.closePath()
    return pen.glyph(),int((w-1)*xscale + xpad+RIGHT)

def tight_mask(char):
    arr,_=bitmap_cache[char]
    y,x=np.where(arr>0)
    return arr[y.min():y.max()+1,x.min():x.max()+1]

def put_mask(char,mask,base_y=0,xscale=X_SCALE,yscale=Y_SCALE):
    gl,w=mask_glyph(mask,base_y,xscale,yscale)
    nm=cmap.get(ord(char))
    if nm:
        source_glyf[nm]=gl
        font['hmtx'][nm]=(w,MARGIN)

# d mirrors the sample's distinctive b (same family of bowl and stem)
b=tight_mask('b')
put_mask('d',cv2.flip(b,1), base_y=-12)
# h uses n's characteristic arch with an extended rising stem.
n=tight_mask('n')
h=np.zeros((n.shape[0]+35,n.shape[1]+1),np.uint8)
h[35:35+n.shape[0],:n.shape[1]]=n
# The n stem occupies 36-40 px on the left; extend with a slightly leaning shaft
cv2.rectangle(h,(3,4),(38,65),255,-1)
cv2.ellipse(h,(19,5),(18,5),0,0,360,255,-1)
put_mask('h',h,base_y=0)
# m: two close, overlapping arches with no double-thick interior stem.
m=np.zeros((n.shape[0]+1,n.shape[1]+82),np.uint8)
m[:n.shape[0],:n.shape[1]]=n
m[:n.shape[0],80:80+n.shape[1]]=np.maximum(m[:n.shape[0],80:80+n.shape[1]],n)
put_mask('m',m)
# l based on the real ascending stem of b.
left=b[:,:41].copy(); yl=np.where(left>0)[0]
if len(yl): left=left[yl.min():yl.max()+1]
put_mask('l',left,base_y=-8)
# i uses the same stem shape, cropped to x-height with a detached dot.
ist=left.copy()
ish=int(round(113))
ist=cv2.resize(ist,(ist.shape[1],ish),interpolation=cv2.INTER_NEAREST)
imask=np.zeros((ish+39,ist.shape[1]+1),np.uint8)
imask[39:,1:1+ist.shape[1]]=ist
cv2.ellipse(imask,(int(ist.shape[1]*.51),16),(17,15),-7,0,360,255,-1)
put_mask('i',imask,base_y=0)
# e from the photographed c: bring a thick, playful crossbar through its
# opening. This preserves the open mouth instead of accidentally making an 8.
c=tight_mask('c')
e=cv2.resize(c,(int(c.shape[1]*1.17),c.shape[0]),interpolation=cv2.INTER_LINEAR)
eh,ew=e.shape
cv2.line(e,(int(ew*.24),int(eh*.53)),(int(ew*.81),int(eh*.53)),255,15)
put_mask('e',e)
# q/p use the photo's b bowl, but stem extends below instead of above; retain
# similar silhouette via current letter contours if present in base font.

# Fallback characters: keep Noto Sans Black's strong legibility, but make width and
# height feel closer to the compact photographed lettering. The punctuation not
# traced stays dependable at small sizes.
# Need adjust glyphs not replaced; they are drawn at original width and much too
# geometrical otherwise. Apply a rounded, slightly squeezed transform.
modified={cmap[ord(c)] for c in list(RECTS)+list('dhmlie') if ord(c) in cmap}
for name in list(font.getGlyphOrder()):
    if name in modified or name=='.notdef' or name not in source_glyf.glyphs:
        continue
    # Composite accented glyphs may reference altered components, so preserve
    # composites instead of flattening them. Standard original outlines remain.
    if source_glyf[name].isComposite():
        continue
    g=source_glyf[name]
    # Don't distort special marks (accent compatibility), preserve natural clarity.
    if name not in [cmap.get(v) for v in range(0x21,0x7F)]:
        continue
    # Draw transformed fallback with original outlines (upscale mild, close tracking)
    pp=TTGlyphPen(font.getGlyphSet())
    tpen=TransformPen(pp,(0.91,0,0,1.035,0,0))
    try:
        base_glyphs[name].draw(tpen)
        new=pp.glyph()
        source_glyf[name]=new
        aw,lsb=font['hmtx'][name]
        font['hmtx'][name]=(max(140,int(aw*0.91)),int(lsb*0.91))
    except Exception as ex:
        print('Fallback drawing failed',name,ex)

# Rename the modified family; do not use reserved source font family name.
family='Lobang Pop'
post='LobangPop-Heavy'
full='Lobang Pop Heavy'
for nameID,val in [(1,family),(2,'Heavy'),(3,'LobangPopHeavy-1.0'),(4,full),(6,post),(16,family),(17,'Heavy'),(13,'Licensed under SIL OFL 1.1; based partly on Noto Sans Black')]:
    font['name'].setName(val,nameID,3,1,0x409)
    font['name'].setName(val,nameID,1,0,0)
font['OS/2'].usWeightClass=900
font['OS/2'].sxHeight=590
font['OS/2'].sCapHeight=740
font['OS/2'].sTypoAscender=805
font['OS/2'].sTypoDescender=-225
font['OS/2'].sTypoLineGap=50
font['hhea'].ascent=805
font['hhea'].descent=-225
font['hhea'].lineGap=50
font['head'].macStyle |= 1
font['post'].italicAngle=0
font.recalcBBoxes=True
font.recalcTimestamp=False
font.flavor=None
font.save(OUT/'LobangPop-Heavy.ttf')
for suffix in ('woff','woff2'):
    font.flavor=suffix
    font.save(OUT/f'LobangPop-Heavy.{suffix}')
font.flavor=None
print('glyph count',len(font.getGlyphOrder()))
for fn in OUT.iterdir():print(fn.name,fn.stat().st_size)
