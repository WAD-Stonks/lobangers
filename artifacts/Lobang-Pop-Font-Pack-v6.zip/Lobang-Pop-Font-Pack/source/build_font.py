#!/usr/bin/env python3
"""Rebuild revision 5 from the archived original, preserving authentic traces.
Requires fonttools and brotli. Run from any directory.
"""
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.reverseContourPen import ReverseContourPen
from fontTools.svgLib.path import parse_path
from fontTools.feaLib.builder import addOpenTypeFeaturesFromString
from custom_shapes import CAPS, E_LOWER, LOWER
HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'fonts'
font=TTFont(HERE/'LobangPop-Original.ttf',recalcTimestamp=False)
cmap=font.getBestCmap()
for char,path in {**CAPS,'e':E_LOWER,**LOWER}.items():
    pen=TTGlyphPen(None)
    quadratic=Cu2QuPen(ReverseContourPen(pen),max_err=0.65,reverse_direction=False)
    transform=(5.14,0,0,-5.03,24,750 if char.isupper() else 570)
    parse_path(path,TransformPen(quadratic,transform))
    glyph=pen.glyph(); glyph.recalcBounds(font['glyf'])
    font['glyf'][cmap[ord(char)]]=glyph
    font['hmtx'][cmap[ord(char)]]=(glyph.xMax+28,glyph.xMin)
# Original kerning was calculated for the upstream font's different outlines.
for table in ('GPOS','GSUB','GDEF','kern'):
    if table in font: del font[table]
pairs={'AV':-30,'AW':-22,'AY':-30,'AT':-20,'TA':-22,'To':-25,'Ta':-25,'Te':-25,'Ty':-12,'VA':-30,'Vo':-20,'Va':-20,'WA':-20,'Wo':-15,'Yo':-25,'Ya':-25,'Ye':-25,'LT':-20,'LY':-24,'FA':-16}
fea='feature kern {\n'+''.join(f'pos {cmap[ord(p[0])]} {cmap[ord(p[1])]} {v};\n' for p,v in pairs.items())+'} kern;'
addOpenTypeFeaturesFromString(font,fea)
for platform,encoding,lang in [(3,1,0x409),(1,0,0)]:
    for key,val in {1:'Lobang Pop',2:'Heavy',3:'LobangPopHeavy-5.000',4:'Lobang Pop Heavy',5:'Version 5.000',6:'LobangPop-Heavy',16:'Lobang Pop',17:'Heavy'}.items():
        font['name'].setName(val,key,platform,encoding,lang)
font['head'].fontRevision=5.0
font['OS/2'].fsSelection |= 0x20
font['OS/2'].fsSelection &= ~0x40
# Keep inherited extended characters within line metrics as well.
for name in font.getGlyphOrder():
    font['glyf'][name].recalcBounds(font['glyf'])
asc=max(g.yMax for g in font['glyf'].glyphs.values() if hasattr(g,'yMax'))
desc=min(g.yMin for g in font['glyf'].glyphs.values() if hasattr(g,'yMin'))
font['OS/2'].usWinAscent=asc
font['OS/2'].usWinDescent=abs(desc)
font['OS/2'].sCapHeight=750
font['OS/2'].sxHeight=570
font['head'].modified=3875126400
for flavor in (None,'woff','woff2'):
    font.flavor=flavor
    font.save(OUT/('LobangPop-Heavy.'+(flavor or 'ttf')))
print('Exported TTF, WOFF and WOFF2; uppercase B and all other reference traces retained.')
